package com.example.assessment.view

import android.graphics.Bitmap
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.LruCache
import android.widget.GridView
import android.widget.Toast
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.GridLayoutManager
import com.example.assessment.MainRepository
import com.example.assessment.MainViewModel
import com.example.assessment.MyViewModelFactory
import com.example.assessment.databinding.ActivityMainBinding
import com.example.assessment.model.network_model.LoadImage
import com.example.assessment.network.ApiClient

class MainActivity : AppCompatActivity() {
    // memory cache
    private lateinit var memoryCache: LruCache<String, Bitmap>
    lateinit var viewModel: MainViewModel
     val adapter = GridViewAdapter()
    lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        // setContentView(binding.root)
        val retrofitService = ApiClient.apiService
        val mainRepository = MainRepository(retrofitService)

        binding.gridView.layoutManager=GridLayoutManager(this,3)
        binding.gridView.adapter = adapter
        viewModel = ViewModelProvider(
            this,
            MyViewModelFactory(mainRepository)
        )[MainViewModel::class.java]

        viewModel.imageList.observe(this) {
            adapter.updateList(it)
        }
        viewModel.errorMessage.observe(this) {
            Toast.makeText(this, it, Toast.LENGTH_SHORT).show()
        }
        viewModel.getImageList()

    }
}