/*
package com.example.assessment.room

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.assessment.model.room_model.LoadImageItemRoom


@Database(entities = [LoadImageItemRoom::class], version = 1, exportSchema = false)

abstract class LocalDatabase : RoomDatabase() {

    abstract fun loginDao() : DAOAccess

    companion object {

        @Volatile
        private var INSTANCE: LocalDatabase? = null

        fun getDatabaseClient(context: Context) : LocalDatabase? {

            if (INSTANCE != null) return INSTANCE

            synchronized(this) {

                INSTANCE = Room
                    .databaseBuilder(context, LocalDatabase::class.java, "LOCAL_DATABASE")
                    .fallbackToDestructiveMigration()
                    .build()

                return INSTANCE

            }
        }

    }

}*/
