/*
package com.example.assessment.model.room_model

import androidx.room.ColumnInfo
import androidx.room.Entity
import com.google.gson.annotations.SerializedName

@Entity(tableName = "BackupDetails")
data class BackupDetailsRoom(
    @SerializedName("pdfLink")
    @ColumnInfo(name = "pdfLink")
    var pdfLink: String,
    @SerializedName("screenshotURL")
    @ColumnInfo(name = "screenshotURL")
    var screenshotURL: String? = ""
)*/
