/*
package com.example.assessment.model.room_model

class LoadImageRoom(loadImageList: LoadImageItemRoom) : ArrayList<LoadImageItemRoom>()*/
