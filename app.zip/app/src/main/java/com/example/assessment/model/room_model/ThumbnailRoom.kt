/*
package com.example.assessment.model.room_model

import androidx.room.ColumnInfo
import com.google.gson.annotations.SerializedName

data class ThumbnailRoom(
    @SerializedName("aspectRatio")
    @ColumnInfo(name = "aspectRatio")
    val aspectRatio: Int,
    @SerializedName("basePath")
    @ColumnInfo(name = "basePath")
    val basePath: String,
    @SerializedName("domain")
    @ColumnInfo(name = "domain")
    val domain: String,
    @SerializedName("id")
    @ColumnInfo(name = "id")
    val id: String,
    @SerializedName("key")
    @ColumnInfo(name = "key")
    val key: String,
    @SerializedName("qualities")
    @ColumnInfo(name = "qualities")
    val qualities: List<Int>,
    @SerializedName("version")
    @ColumnInfo(name = "version")
    val version: Int
)*/
