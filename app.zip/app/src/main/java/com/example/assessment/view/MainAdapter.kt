package com.example.assessment.view

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ImageView
import android.widget.TextView
import androidx.core.net.toUri
import com.example.assessment.R
import com.example.assessment.model.network_model.LoadImage
import java.net.URL
import kotlin.concurrent.thread

class MainAdapter : BaseAdapter() {

    var data = mutableListOf<LoadImage>()
    private lateinit var context: Context

    fun setImageList(imageList: List<LoadImage>, context: Context) {
        this.data = imageList.toMutableList()
        this.context = context
        notifyDataSetChanged()
    }
    override fun getCount(): Int {
        return data.size
    }

    override fun getItem(position: Int): LoadImage {
       return data[position]
    }

    override fun getItemId(position: Int): Long {
        return position.toLong()
    }

    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
        val gridItem = getItem(position)

        val view: View
        val viewHolder: ViewHolder

        if (convertView == null) {
            view = LayoutInflater.from(context).inflate(R.layout.grid_item_layout, parent, false)
            viewHolder = ViewHolder()
            viewHolder.imageView = view.findViewById(R.id.imageView)
            viewHolder.textView = view.findViewById(R.id.textView)
            view.tag = viewHolder
        } else {
            view = convertView
            viewHolder = view.tag as ViewHolder
        }

        viewHolder.imageView.bindImage(gridItem.get(position).backupDetails.screenshotURL)
        viewHolder.textView.text = gridItem.get(position).title ?: ""

        return view
    }

    private class ViewHolder { 
        lateinit var imageView: ImageView
        lateinit var textView: TextView
    }

    private fun ImageView.bindImage(imgUrl: String?) {


        if(this.drawable == null) {

            imgUrl?.let {
                val imgUri = imgUrl.toUri().buildUpon().scheme("https").build().toString()


                val uiHandler = Handler(Looper.getMainLooper())
                thread(start = true) {
                    val bitmap = downloadBitmap(imgUri)
                    uiHandler.post {
                        this.setImageBitmap(bitmap)
                    }
                }
            } ?: kotlin.run {  }
        }

    }

    private fun downloadBitmap(imageUrl: String): Bitmap? {
        return try {
            val conn = URL(imageUrl).openConnection()
            conn.connect()
            val inputStream = conn.getInputStream()
            val bitmap = BitmapFactory.decodeStream(inputStream)
            inputStream.close()
            bitmap
        } catch (e: Exception) {
            Log.e("testimg", "Exception $e")
            null
        }
    }


}

