/*
package com.example.assessment.model.room_model

import androidx.room.ColumnInfo
import androidx.room.Entity
import com.example.assessment.model.network_model.BackupDetails
import com.example.assessment.model.network_model.Thumbnail
import com.google.gson.annotations.SerializedName

@Entity(tableName = "LoadImage")
data class LoadImageItemRoom(
    @SerializedName("backupDetails")
    @ColumnInfo(name = "backupDetails")
    var backupDetails: BackupDetails,
    @SerializedName("coverageURL")
    @ColumnInfo(name = "coverageURL")
    var coverageURL: String,
    @SerializedName("id")
    @ColumnInfo(name = "id")
    var id: String,
    @SerializedName("language")
    @ColumnInfo(name = "language")
    val language: String,
    @SerializedName("mediaType")
    @ColumnInfo(name = "mediaType")
    var mediaType: Int,
    @SerializedName("publishedAt")
    @ColumnInfo(name = "publishedAt")
    var publishedAt: String,
    @SerializedName("publishedBy")
    @ColumnInfo(name = "publishedBy")
    var publishedBy: String,
    @SerializedName("thumbnail")
    @ColumnInfo(name = "thumbnail")
    var thumbnail: Thumbnail,
    @SerializedName("title")
    @ColumnInfo(name = "title")
    var title: String
)

*/
