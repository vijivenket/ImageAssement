package com.example.assessment.model.network_model

class LoadImage : ArrayList<LoadImageItem>()